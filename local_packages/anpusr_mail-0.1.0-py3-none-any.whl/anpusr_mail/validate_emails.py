"""Check if a list of email addresses are valid."""

from validate_email import validate_email


def validate(emails):
    """
    Check if a list of email addresses are valid.

    Args:
        emails (list): A list of strings representing email addresses.

    Returns:
        bool: True if all email addresses in the input list are valid,
        False otherwise.
    """
    for email in emails:
        if not validate_email(email):
            return False
    return True
