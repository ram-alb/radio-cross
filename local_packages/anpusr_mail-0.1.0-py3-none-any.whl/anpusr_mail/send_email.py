"""Send an email message with optional attachments."""

import os
import smtplib
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from anpusr_mail.validate_emails import validate
from dotenv import load_dotenv

load_dotenv()


def send_email(to, subject, message, filepath=None, cc=None):
    """
    Send an email message with optional attachments.

    Args:
        to (list): List of recipient email addresses.
        subject (str): Email subject line.
        message (str): Body of the email message.
        filepath (str, optional): File path of the attachment to include.
        cc (list, optional): List of CC email addresses.

    Raises:
        ValueError: If any of the email addresses are invalid or the specified
                    file path does not exist.
    """
    if not validate(to):
        raise ValueError("Invalid 'to' email addresses")
    if cc is not None and not validate(cc):
        raise ValueError("Invalid 'cc' email addresses")
    if filepath is not None and not os.path.isfile(filepath):
        raise ValueError('File not found')

    fromaddr = os.getenv('EMAIL_ADDRESS')

    msg = MIMEMultipart()
    msg['From'] = fromaddr
    msg['To'] = ','.join(to)

    if cc is not None:
        msg['CC'] = ','.join(cc)
        toaddr = to + cc
    else:
        toaddr = to

    msg['Subject'] = subject
    msg.attach(MIMEText(message, 'plain'))

    if filepath is not None:
        with open(filepath, 'rb') as attachment:
            attachment_part = MIMEBase('application', 'octet-stream')
            attachment_part.set_payload((attachment).read())
            encoders.encode_base64(attachment_part)

            filename = os.path.basename(filepath)
            attachment_part.add_header(
                'Content-Disposition',
                f'attachment; filename= {filename}',
            )
            msg.attach(attachment_part)
    with smtplib.SMTP(os.getenv('EMAIL_HOST')) as smtp_server:
        text = msg.as_string()
        smtp_server.sendmail(fromaddr, toaddr, text)
