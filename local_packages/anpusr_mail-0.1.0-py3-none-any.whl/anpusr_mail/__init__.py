"""Send an email message."""

from anpusr_mail.send_email import send_email
